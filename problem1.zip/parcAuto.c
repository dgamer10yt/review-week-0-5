#include <stdio.h>

typedef struct Masina
{
    char* marca;
    char *model;
    char tokenMasina[11];
    int pretAchizitie;
    int pretVanzare
}Masina;

int main(int main argc, char *argv[])
{
    FILE *inputCerinte = fopen(argv[1], "r")
}